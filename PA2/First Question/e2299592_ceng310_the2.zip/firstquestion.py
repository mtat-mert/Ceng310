import stacknque
def transfer(S,T):
    while not S.isempty():
        T.push(S.pop())















